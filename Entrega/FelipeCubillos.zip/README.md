# INSTRUCCIONES DE USO

El programa está diseñado para ser descomprimido e inmediatamente ejecutado, por lo que depende que el directorio en el que sea extraido contenga

- El script con formato `.ipynb`
- Un directorio con las imágenes en el mismo nivel que el script titulado `./images`

**SI NO SE CUMPLE; EL PROGRAMA NO SE VA A EJECUTAR, se deben de utilizar las 4 imágenes ya entregadas en el `.zip`.**